const SHEET_URL = 'https://script.google.com/macros/s/AKfycbwF01VM_NXs7WiBznpfkZoTDUzwQihm9gZQH7qkavY1SPPA9CykIrXO-7ZyR68uQZ1_/exec';

exports.handler = async function(event, context) {
  const headers = {
    'Access-Control-Allow-Origin': '*',
    'Access-Control-Allow-Headers': 'Content-Type',
    'Access-Control-Allow-Methods': 'GET, POST, OPTIONS',
    'Content-Type': 'application/json',
  };

  if (event.httpMethod === 'OPTIONS') {
    return { statusCode: 200, headers, body: '' };
  }

  try {
    let googleRes, text;

    if (event.httpMethod === 'GET') {
      const url = SHEET_URL + '?action=load&t=' + Date.now();
      console.log('Fetching:', url);
      googleRes = await fetch(url, {
        method: 'GET',
        redirect: 'follow',
        headers: { 'Accept': 'application/json' }
      });
      console.log('Google status:', googleRes.status);
      text = await googleRes.text();
      console.log('Google response (first 200):', text.substring(0, 200));

    } else if (event.httpMethod === 'POST') {
      const body = JSON.parse(event.body);
      console.log('POSTing action:', body.action);
      googleRes = await fetch(SHEET_URL, {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify(body),
        redirect: 'follow',
      });
      console.log('Google POST status:', googleRes.status);
      text = await googleRes.text();
    }

    // Try to parse JSON
    let data;
    try {
      data = JSON.parse(text);
    } catch(e) {
      console.log('JSON parse failed, raw text:', text.substring(0, 500));
      return {
        statusCode: 200,
        headers,
        body: JSON.stringify({ status: 'error', error: 'Invalid JSON from Google', raw: text.substring(0, 200) }),
      };
    }

    return {
      statusCode: 200,
      headers,
      body: JSON.stringify(data),
    };

  } catch (err) {
    console.log('Function error:', err.message);
    return {
      statusCode: 500,
      headers,
      body: JSON.stringify({ status: 'error', error: err.message }),
    };
  }
};
